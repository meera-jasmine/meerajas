require('dotenv').config();
const http = require('http');
const app = require('./index'); // Make sure 'index.js' exports your Express app
const server = http.createServer(app);

// Start the server
server.listen(process.env.PORT, () => {
    console.log(`Server is running on port ${process.env.PORT}`);
});
